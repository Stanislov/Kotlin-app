package com.example.misecapp.ui.gallery

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class GalleryViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "В данной таблице расположены основные глаголы \n Их знание облегчит вам жизнь "
    }
    val text: LiveData<String> = _text
}