package com.example.misecapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class TableActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_table)
    }
    fun backMe (view: View) {
        val backIntent = Intent (this, MainActivity::class.java)

        startActivity(backIntent)
    }
}
